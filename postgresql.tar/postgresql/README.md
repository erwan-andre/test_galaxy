# minarm.postgresql

## Description
Collection proposant la gestion de PostgreSQL

## Contenu
### Rôles
  * ``` minarm.postgresql.postgresql_install ``` | *Installe et configuration une instance*
  * ``` minarm.postgresql.postgresql_replica ``` | *Installe et configuration une réplication*

### Playbooks
  * ``` minarm.postgresql.postgresql_upgrade ``` | *Monte de version majeur l'intance*
  * ``` minarm.postgresql.postgresql_check ``` | *Génère un rapport d'installation*
  * ``` minarm.postgresql.postgresql_service ``` | *Gère le service système*
  * ``` minarm.postgresql.postgresql_uninstall ``` | *Dé-installe une instance*
  * ``` minarm.postgresql.postgresql_dump ``` | *Export/Import des fichiers de sauvegarde*
