# minarm.postgresql.postgresql_install

## Description
**Dépendances : ```minarm.core```**

Rôle d'installation et de configuration de PostgreSQL<br/>
**Version supportée : ```11```, ```12```, ```13``` ,```14```**

## Configuration minimale
**```postgresql_version: 13```** | Version de PostgreSQL<br/>
**```postgresql_unixAccount_password: mdpUnix```** | Mot de passe du compte Unix<br/>
**```postgresql_dbAccount_password: mdpDB```** | Mot de passe du compte administrateur PostgreSQL<br/>

## Configurations avancée
### Installation
La version de PostgreSQL peut-être définie de 2 manières.
  * **```postgresql_version: 13.2```** | Installe précissement la version
  * **```postgresql_version: 13```** | Installe la version la plus récente

### Renommage comptes Unix/BDD
La renommage du compte Unix et/ou Administrateur BDD, peuvent être éffectuer via les variables suivantes. 
  * **```postgresql_unixAccount```** | Nom du compte Unix
  * **```postgresql_dbAccount```** | Nom du compte administrateur PostgreSQL

**Exemple :**
```
postgresql_unixAccount: postgres
postgresql_unixAccount_password: pwdpostgres

postgresql_dbAccount: pgadmin
postgresql_dbAccount_password: pwdpgadmin
```

### Paramétrage
La configuration par défaut de l'instance PostgreSQL est la suivant:
  * **```postgresql_port: 5432```** | Port d'écoute
  * **```postgresql_maxConnections: 100```** | Nombres de connections autorisée
  * **```postgresql_encryption: scram-sha-256```** | Chiffrement de la base de données
  * **```postgresql_listenAddresses: localhost```** | Adresse(s) IP d'écoute

La configuration avancée, se réaliser via la variable : **```postgresql_configuration```**<br/>
Pour ajouter une configuration ***(liste des paramètres : <https://postgresqlco.nf/doc/fr/param/>)*** :

**Exemple :**
```
postgresql_configuration:
  - key: log_filename
    value: postgresql-%Y-%m-%d_%H%M%S.log
  - key: log_connections
    value: on 
  - key: log_disconnections
    value: on
```
La variables **```postgresql_configuration```** s'ajoute automatiquement aux valeurs par défaut

La configuration de la mémoire automatique est effectuée via la variable **```postgresql_customMemory```**

**Exemple :**
```
postgresql_customMemory: true   #Configure la mémoire automatiquement
postgresql_customMemory: false  #Utilise la configuration par défaut de PostgreSQL
```

### Environnement
Si **```postgresql_environnement```** reste vide aucun environnement (base de données) ne sera créé.

Pour créer une base de données "standard", les élément ci-dessus et ci-dessous doivent être renseigner.<br/>

  * **```database:```** | Nom de la base de données
  * **```roles:```** | Liste contenant les roles (user)
    * **```name: xxxx```** | Nom du role
    * **```password: xxxx```** | Mot de passe du role
    * **```privs:```** | Liste des privilèges associés au role
      * **```privs: all```** | Nom des privilèges *(select,update,...)*
      * **```schema: public```** | Nom du schema
    * **```host: xxx.xxx.xxx.xxx```** | Adresse IP du serveur Applicatif
  * **```template: template0```** | Nom du template
  * **```schema: ["public"]```** | Liste des schémas
  * **```extension: []```** | liste des extensions

**Exemple basique :**
```
postgresql_environnement:
  - database: db2
    roles:
      - name: db2User
        password: db2Pwd
        privs:
          - privs: all
            schema: public
        host: 127.0.0.1
    template: template0
    schema:
      - public
    extension: []
```

**Exemple avancée :**
```
postgresql_environnement:
  - database: db1
    roles:
      - name: db1User_1
        password: db1Pwd
        privs:
          - privs: select
            schema: sch_1
          - privs: insert,delete
            schema: sch_2
        host: 127.0.0.1
      - name: db1User_2
        password: db1Pwd
        privs:
          - privs: insert,delete
            schema: sch_1
          - privs: select
            schema: sch_2
        host: 127.0.0.1
    template: template0
    schema:
      - sch_1
      - sch_2
      - sch_3
    extension:
      - unaccent
    extension: []
```

Erwan ANDRE <erwan.andre-jouron@intradef.gouv.fr>
