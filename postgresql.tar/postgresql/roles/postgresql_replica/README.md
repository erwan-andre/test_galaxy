# minarm.postgresql.postgresql_replica

## Description
**Dépendances : ```minarm.core```** et **```minarm.postgresql.postgresql_install```**

Rôle d'installation et de configuration une réplication PostgreSQL<br/>
**Réplication supportée : ```1 Primaire et n Standby```**

## Configuration
  * **```postgresql_replicaMembers: []```** | Liste des serveurs PostgreSQL<br/>
  * **```postgresql_replUser_password: mdpReplica```** | Mot de passe du compte de réplication PostgreSQL

La liste des serveurs PostgreSQL doit-être définie comme suite :<br/>
*Le 1er serveur de la liste hérite du status de **Primaire** et le reste hérite du status de **Standby***

**Exemple :**
```
postgresql_replicaMembers: "{{ groups['postgresql'] }}"
postgresql_replUser_password: replicat
```

Erwan ANDRE <erwan.andre-jouron@intradef.gouv.fr>
